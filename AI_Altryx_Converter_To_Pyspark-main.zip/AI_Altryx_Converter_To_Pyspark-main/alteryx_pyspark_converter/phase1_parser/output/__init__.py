"""Phase 1 output writers."""

from .json_writer import JSONWriter

__all__ = ["JSONWriter"]
